export const environment = {
  production: true,

  firebase: {
    apiKey: <<Your Key>>,
    authDomain: <<Your Key>>,
    databaseURL: <<Your Key>>,
    projectId: <<Your Key>>,
    storageBucket: <<Your Key>>,
    messagingSenderId: <<Your Key>>,
    appId: <<Your Key>>
  }
};
