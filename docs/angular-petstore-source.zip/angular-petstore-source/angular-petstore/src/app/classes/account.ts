export class Account {
    email: string;
    password?: string;
    name?: string;
    country?: string;
    city?: string;
    address?: string;
    zip?: string;    
    photoURL?: string;
    uid?: string;
}
