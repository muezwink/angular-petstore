import { Dialog } from './dialog';

describe('Dialog', () => {
  it('should create an instance', () => {
    expect(new Dialog()).toBeTruthy();
  });
});
