export class Item {
    key: string;
    id: string;
    name: string;   
    available: boolean;
}
